// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iomanip>
#include <iostream>
#include <limits>

int main()
{
  std::cout << "Buffer Overflow Example" << std::endl;

  // TODO: The user can type more than 20 characters and overflow the buffer, resulting in account_number being replaced -
  //  even though it is a constant and the compiler buffer overflow checks are on.
  //  You need to modify this method to prevent buffer overflow without changing the account_number
  //  variable, and its position in the declaration. It must always be directly before the variable used for input.
  //  You must notify the user if they entered too much data.

  // The real problem was that cin >> user_input had no idea
  // how big the user_input array actually was so it just kept writing characters straight into
  // memory even past the end of it which is exactly what let it spill into account_number sitting
  // right next to it on the stack. std::setw which comes from iomanip and was already included up
  // top fixes that by putting a hard cap on how many characters cin is allowed to write into
  // user_input in the first place so the overflow at that point literally cannot happen anymore no matter what
  // the user types in... I used sizeof(user_input) instead of just hardcoding the number 20 so this
  // still works correctly even if someone changes the buffer size later on

  const std::string account_number = "CharlieBrown42";
  char user_input[20];
  std::cout << "Enter a value: ";
  std::cin >> std::setw(sizeof(user_input)) >> user_input;

  // setw quietly stops reading once it hits that cap but it does not actually tell me if it had to
  // cut anything off so I check the stream myself right after. If there is still a character sitting
  // in the input that is not the newline from the user hitting enter then at that point that means they typed more than
  // what fit in the buffer so I warn them here and then clear out whatever is left over so it does
  // not accidentally get picked up by anything else that reads from cin later
  if (std::cin.peek() != '\n' && !std::cin.eof())
  {
    std::cout << "Warning! Your input was too long and got cut off at "
              << (sizeof(user_input) - 1) << " characters to keep it from overwriting other memory." << std::endl;
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
  }

  std::cout << "You entered: " << user_input << std::endl;
  std::cout << "Account Number = " << account_number << std::endl;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
