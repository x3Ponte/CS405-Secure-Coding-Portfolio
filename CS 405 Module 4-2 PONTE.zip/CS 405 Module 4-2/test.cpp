// Uncomment the next line to use precompiled headers
//#include "pch.h"
// uncomment the next line if you do not use precompiled headers
#include "gtest/gtest.h"

// I ended up flipping these two lines above. pch.h is a visual studio only precompiled
// header thing it does not exist here on my mac so I justcommented that line out
// and uncommented the plain gtest/gtest.h include instead like the existing
// comment above it already said to do if I am not using precompiled headers...

#include <vector>
#include <memory>
#include <stdexcept>
#include <cassert>
#include <ctime>

// I added these last two includes myself as well. cassert is for the assert() call already used down in add_entries and ctime is for time() used in srand(time(nullptr)) in the environment class below. precompiled headers on windows would have automatically pulled these in for me but since I am not using those here I need to bring them in myself so this builds the same way on my mac.

// the global test environment setup and tear down
// you should not need to change anything here
class Environment : public ::testing::Environment
{
public:
  ~Environment() override {}

  // Override this to define how to set up the environment.
  void SetUp() override
  {
    //  initialize random seed
    srand(time(nullptr));
  }

  // Override this to define how to tear down the environment.
  void TearDown() override {}
};

// create our test class to house shared data between tests
// you should not need to change anything here
class CollectionTest : public ::testing::Test
{
protected:
  // create a smart point to hold our collection
  std::unique_ptr<std::vector<int>> collection;

  void SetUp() override
  { // create a new collection to be used in the test
    collection.reset( new std::vector<int>);
  }

  void TearDown() override
  { //  erase all elements in the collection, if any remain
    collection->clear();
    // free the pointer
    collection.reset(nullptr);
  }

  // helper function to add random values from 0 to 99 count times to the collection
  void add_entries(int count)
  {
    assert(count > 0);
    for (auto i = 0; i < count; ++i)
      collection->push_back(rand() % 100);
  }
};

// When should you use the EXPECT_xxx or ASSERT_xxx macros?
// Use ASSERT when failure should terminate processing, such as the reason for the test case.
// Use EXPECT when failure should notify, but processing should continue

// Test that a collection is empty when created.
// Prior to calling this (and all other TEST_F defined methods),
//  CollectionTest::StartUp is called.
// Following this method (and all other TEST_F defined methods),
//  CollectionTest::TearDown is called
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
  // is the collection created
  ASSERT_TRUE(collection);

  // if empty, the size must be 0
  ASSERT_NE(collection.get(), nullptr);
}

// Test that a collection is empty when created.
TEST_F(CollectionTest, IsEmptyOnCreate)
{
  // is the collection empty?
  ASSERT_TRUE(collection->empty());

  // if empty, the size must be 0
  ASSERT_EQ(collection->size(), 0);
}

/* Comment this test out to prevent the test from running
 * Uncomment this test to see a failure in the test explorer */
// I ran this one once with it turned on just to see what a failing test looks like in the output like the comment suggests then commented the whole TEST_F block out below so the rest of my tests can run clean
/*
TEST_F(CollectionTest, AlwaysFail)
{
  FAIL();
}
*/

// TODO: Create a test to verify adding a single value to an empty collection
TEST_F(CollectionTest, CanAddToEmptyVector)
{
  // is the collection empty?
  // if empty, the size must be 0

  // I added these two asserts myself to actually prove the collection starts empty before I add anything to it matching what the earlier IsEmptyOnCreate test already checks just here so this test proves its own starting point
  ASSERT_TRUE(collection->empty());
  ASSERT_EQ(collection->size(), 0);

  add_entries(1);

  // is the collection still empty?
  // if not empty, what must the size be?

  // after adding exactly 1 entry the collection should no longer be empty and its size should be exactly 1...
  EXPECT_FALSE(collection->empty());
  EXPECT_EQ(collection->size(), 1);
}

// TODO: Create a test to verify adding five values to collection
TEST_F(CollectionTest, CanAddFiveValuesToVector)
{
  add_entries(5);

  // after adding 5 entries the size should be exactly 5
  EXPECT_EQ(collection->size(), 5);
}

// TODO: Create a test to verify that max size is greater than or equal to size for 0, 1, 5, 10 entries

// max_size() is basically the upper limit of how big the vector
// could ever grow so it should always be greater than or equal to whatever the current size actually is no matter how many entries I add
TEST_F(CollectionTest, MaxSizeGreaterThanOrEqualToSize)
{
  // 0 entries
  EXPECT_GE(collection->max_size(), collection->size());

  // 1 entry
  add_entries(1);
  EXPECT_GE(collection->max_size(), collection->size());

  // 5 entries
  add_entries(4);
  EXPECT_GE(collection->max_size(), collection->size());

  // 10 entries
  add_entries(5);
  EXPECT_GE(collection->max_size(), collection->size());
}

// TODO: Create a test to verify that capacity is greater than or equal to size for 0, 1, 5, 10 entries

// capacity() is how much room the vector currently has reserved before it needs to reallocate that should always be greater than or equal to size() as well.. same idea as max_size just at a smaller scale.
TEST_F(CollectionTest, CapacityGreaterThanOrEqualToSize)
{
  // 0 entries
  EXPECT_GE(collection->capacity(), collection->size());

  // 1 entry
  add_entries(1);
  EXPECT_GE(collection->capacity(), collection->size());

  // 5 entries
  add_entries(4);
  EXPECT_GE(collection->capacity(), collection->size());

  // 10 entries
  add_entries(5);
  EXPECT_GE(collection->capacity(), collection->size());
}

// TODO: Create a test to verify resizing increases the collection
TEST_F(CollectionTest, ResizeIncreasesCollection)
{
  add_entries(5);
  ASSERT_EQ(collection->size(), 5);

  // resizing up to 10 should grow the size to 10.
  collection->resize(10);

  EXPECT_EQ(collection->size(), 10);
}

// TODO: Create a test to verify resizing decreases the collection
TEST_F(CollectionTest, ResizeDecreasesCollection)
{
  add_entries(10);
  ASSERT_EQ(collection->size(), 10);

  // resizing down to 5 should shrink the size to 5..
  collection->resize(5);

  EXPECT_EQ(collection->size(), 5);
}

// TODO: Create a test to verify resizing decreases the collection to zero
TEST_F(CollectionTest, ResizeDecreasesCollectionToZero)
{
  add_entries(10);
  ASSERT_EQ(collection->size(), 10);

  // resizing all the way down to 0 should leave the collection empty
  collection->resize(0);

  EXPECT_EQ(collection->size(), 0);
  EXPECT_TRUE(collection->empty());
}

// TODO: Create a test to verify clear erases the collection
TEST_F(CollectionTest, ClearErasesCollection)
{
  add_entries(10);
  ASSERT_EQ(collection->size(), 10);

  // clear() should wipe out everything and bring size back to 0
  collection->clear();

  EXPECT_EQ(collection->size(), 0);
  EXPECT_TRUE(collection->empty());
}

// TODO: Create a test to verify erase(begin,end) erases the collection
TEST_F(CollectionTest, EraseBeginEndErasesCollection)
{
  add_entries(10);
  ASSERT_EQ(collection->size(), 10);

  // erasing everything from begin() to end() should have the same effect as clear() an empty collection with a size of 0
  collection->erase(collection->begin(), collection->end());

  EXPECT_EQ(collection->size(), 0);
  EXPECT_TRUE(collection->empty());
}

// TODO: Create a test to verify reserve increases the capacity but not the size of the collection
TEST_F(CollectionTest, ReserveIncreasesCapacityNotSize)
{
  add_entries(5);
  ASSERT_EQ(collection->size(), 5);

  // reserve just sets aside room ahead of time it should never change how many actual elements are in the collection only how much room it has...
  collection->reserve(100);

  EXPECT_GE(collection->capacity(), 100);
  EXPECT_EQ(collection->size(), 5);
}

// TODO: Create a test to verify the std::out_of_range exception is thrown when calling at() with an index out of bounds
// NOTE: This is a negative test
TEST_F(CollectionTest, AtThrowsOutOfRangeWhenIndexIsInvalid)
{
  // the collection starts empty so asking for index 1 is out of bounds and should throw std::out_of_range instead of crashing or returning junk.
  EXPECT_THROW(collection->at(1), std::out_of_range);
}

// TODO: Create 2 unit tests of your own to test something on the collection - do 1 positive & 1 negative

// This is my positive test...
// I wanted to prove push_back does two things at once correctly that it actually grows the size by one and also puts the exact value I gave it at the right spot not just a random value from add_entries
TEST_F(CollectionTest, PushBackIncreasesSizeAndStoresCorrectValue)
{
  collection->push_back(42);

  EXPECT_EQ(collection->size(), 1);
  EXPECT_EQ(collection->at(0), 42);
}

// Negative test
// resize() is supposed to throw std::length_error if I ask it to grow past what max_size() says is even possible so I used that to make a second different negative test than the at() one above
TEST_F(CollectionTest, ResizeBeyondMaxSizeThrowsLengthError)
{
  EXPECT_THROW(collection->resize(collection->max_size() + 1), std::length_error);
}
