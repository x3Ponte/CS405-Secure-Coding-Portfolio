// NumericOverflows.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>     // std::cout
#include <limits>       // std::numeric_limits

/// <summary>
/// Template function to abstract away the logic of:
///   start + (increment * steps)
/// </summary>
/// <typeparam name="T">A type that with basic math functions</typeparam>
/// <param name="start">The number to start with</param>
/// <param name="increment">How much to add each step</param>
/// <param name="steps">The number of steps to iterate</param>
/// <returns>start + (increment * steps)</returns>

// I changed the function signature below...
// I gave add_numbers a new parameter called overflow
// and the reason I did that is so the function has a way to hand back a true or false answer
// telling test_overflow whether it had to stop early because the math was about to go
// out of range for whatever type T happens to be. Before this change the function had
// no way to tell the caller anything went wrong it would just end up returning a wrong number
template <typename T>
T add_numbers(T const& start, T const& increment, unsigned long int const& steps, bool& overflow)
{
    T result = start;
    overflow = false; // I start by assuming nothing bad happens and then flip this if it does

    for (unsigned long int i = 0; i < steps; ++i)
    {
        // This is the actual overflow check so instead of doing the addition first and
        // checking after (which would be too late since the damage is already done..)
        // this checks ahead of time whether result + increment would go past the biggest
        // number type T can hold. I do that by rearranging the math to
        // "result > max - increment" instead of "result + increment > max" because
        // the second version can itself overflow while doing the check which would
        // defeat the whole point here. std::numeric_limits<T>::max() is what gives me the
        // biggest possible value for whatever type T is
        if (increment > 0 && result > std::numeric_limits<T>::max() - increment)
        {
            overflow = true; // letting whoever called this function know it failed
            break;           // I stop the loop right here so I never actually run the bad addition
        }

        result += increment;
    }

    return result;
}

/// <summary>
/// Template function to abstract away the logic of:
///   start - (increment * steps)
/// </summary>
/// <typeparam name="T">A type that with basic math functions</typeparam>
/// <param name="start">The number to start with</param>
/// <param name="increment">How much to subtract each step</param>
/// <param name="steps">The number of steps to iterate</param>
/// <returns>start - (increment * steps)</returns>

template <typename T>
T subtract_numbers(T const& start, T const& decrement, unsigned long int const& steps, bool& underflow)
{
    // Same idea as add_numbers above I just flipped for subtraction. I added an
    // underflow reference parameter here for the same reason so that this function can
    // tell test_underflow it had to bail out early instead of returning a wrapped
    // around number that looks fine but is actually wrong...
    T result = start;
    underflow = false;

    for (unsigned long int i = 0; i < steps; ++i)
    {
        // And here I'm checking if subtracting decrement would drop result below the
        // smallest value T can hold. I used std::numeric_limits<T>::lowest() instead
        // of ::min() on purpose. I looked this up because I got confused at first.
        // min() on a floating point type actually gives you the smallest POSITIVE
        // number not the most negative one, so lowest() is the one that actually
        // means what I want here. For unsigned types lowest() and min() are both 0
        // so it still works fine there.
        if (decrement > 0 && result < std::numeric_limits<T>::lowest() + decrement)
        {
            underflow = true; // telling the caller this one didnt make it either
            break;            // stopping before I actually do the bad subtraction
        }

        result -= decrement;
    }

    return result;
}


//  NOTE:
//    You will see the unary ('+') operator used in front of the variables in the test_XXX methods.
//    This forces the output to be a number for cases where cout would assume it is a character. 

template <typename T>
void test_overflow()
{
    // TODO: The add_numbers template function will overflow in the second method call
    //        You need to change the add_numbers method to:
    //        1. Detect when an overflow will happen
    //        2. Prevent it from happening
    //        3. Return the correct value when no overflow happened or
    //        4. Return something to tell test_overflow the addition failed
    //        NOTE: The add_numbers method must remain a template in the NumericFunctions header.
    //
    //        You need to change the test_overflow method to:
    //        1. Detect when an add_numbers failed
    //        2. Inform the user the overflow happened
    //        3. A successful result displays the same result as before you changed the method
    //        NOTE: You cannot change anything between START / END DO NOT CHANGE
    //              The test_overflow method must remain a template in the NumericOverflows source file
    //
    //  There are more than one possible solution to this problem. 
    //  The solution must work for all of the data types used to call test_overflow() in main().

    // This is what I actually did to knock this TODO out:
    // add_numbers now takes a bool& called overflow, so right after I call it I check
    // that flag. If it's true I print a message saying it overflowed instead of
    // printing whatever half-finished number got returned. If it's false everything
    // worked fine and I print the result exactly like the original code did.

    // START DO NOT CHANGE
    //  how many times will we iterate
    const unsigned long int steps = 5;
    // how much will we add each step (result should be: start + (increment * steps))
    const T increment = std::numeric_limits<T>::max() / steps;
    // whats our starting point
    const T start = 0;

    std::cout << "Overflow Test of Type = " << typeid(T).name() << std::endl;
    // END DO NOT CHANGE

    // this is where add_numbers will tell me if it overflowed...
    bool overflow = false;

    std::cout << "\tAdding Numbers Without Overflow (" << +start << ", " << +increment << ", " << steps << ") = ";
    T result = add_numbers<T>(start, increment, steps, overflow);
    if (overflow)
    {
        // it shouldnt overflow on this first call but I'm checking anyway just in case
        std::cout << "Overflow!" << std::endl;
    }
    else
    {
        std::cout << +result << std::endl;
    }

    std::cout << "\tAdding Numbers With Overflow (" << +start << ", " << +increment << ", " << (steps + 1) << ") = ";
    result = add_numbers<T>(start, increment, steps + 1, overflow);
    if (overflow)
    {
        // this is the call thats actually supposed to overflow so this message is what I expect to see
        std::cout << "Overflow!" << std::endl;
    }
    else
    {
        std::cout << +result << std::endl;
    }
}

template <typename T>
void test_underflow()
{
    // TODO: The subtract_numbers template function will underflow in the second method call
    //        You need to change the subtract_numbers method to:
    //        1. Detect when an underflow will happen
    //        2. Prevent it from happening
    //        3. Return the correct value when no underflow happened or
    //        4. Return something to tell test_underflow the subtraction failed
    //        NOTE: The subtract_numbers method must remain a template in the NumericFunctions header.
    //
    //        You need to change the test_underflow method to:
    //        1. Detect when an subtract_numbers failed
    //        2. Inform the user the underflow happened
    //        3. A successful result displays the same result as before you changed the method
    //        NOTE: You cannot change anything between START / END DO NOT CHANGE
    //              The test_underflow method must remain a template in the NumericOverflows source file
    //
    //  There are more than one possible solution to this problem. 
    //  The solution must work for all of the data types used to call test_overflow() in main().

    // Same approach here as I used in test_overflow. subtract_numbers now takes a
    // bool& called underflow and I check it after each call so I know whether to
    // print the real result or an underflow message.

    // START DO NOT CHANGE
    //  how many times will we iterate
    const unsigned long int steps = 5;
    // how much will we subtract each step (result should be: start - (increment * steps))
    const T decrement = std::numeric_limits<T>::max() / steps;
    // whats our starting point
    const T start = std::numeric_limits<T>::max();

    std::cout << "Underflow Test of Type = " << typeid(T).name() << std::endl;
    // END DO NOT CHANGE

    // this is where subtract_numbers will tell me if it underflowed
    bool underflow = false;

    std::cout << "\tSubtracting Numbers Without Overflow (" << +start << ", " << +decrement << ", " << steps << ") = ";
    auto result = subtract_numbers<T>(start, decrement, steps, underflow);
    if (underflow)
    {
        std::cout << "Underflow!" << std::endl;
    }
    else
    {
        std::cout << +result << std::endl;
    }

    std::cout << "\tSubtracting Numbers With Overflow (" << +start << ", " << +decrement << ", " << (steps + 1) << ") = ";
    result = subtract_numbers<T>(start, decrement, steps + 1, underflow);
    if (underflow)
    {
        std::cout << "Underflow!" << std::endl;
    }
    else
    {
        std::cout << +result << std::endl;
    }
}

void do_overflow_tests(const std::string& star_line)
{
    std::cout << std::endl << star_line << std::endl;
    std::cout << "*** Running Overflow Tests ***" << std::endl;
    std::cout << star_line << std::endl;

    // Testing C++ primative times see: https://www.geeksforgeeks.org/c-data-types/
    // signed integers
    test_overflow<char>();
    test_overflow<wchar_t>();
    test_overflow<short int>();
    test_overflow<int>();
    test_overflow<long>();
    test_overflow<long long>();

    // unsigned integers
    test_overflow<unsigned char>();
    test_overflow<unsigned short int>();
    test_overflow<unsigned int>();
    test_overflow<unsigned long>();
    test_overflow<unsigned long long>();

    // real numbers
    test_overflow<float>();
    test_overflow<double>();
    test_overflow<long double>();
}

void do_underflow_tests(const std::string& star_line)
{
    std::cout << std::endl << star_line << std::endl;
    std::cout << "*** Running Undeflow Tests ***" << std::endl;
    std::cout << star_line << std::endl;

    // Testing C++ primative times see: https://www.geeksforgeeks.org/c-data-types/
    // signed integers
    test_underflow<char>();
    test_underflow<wchar_t>();
    test_underflow<short int>();
    test_underflow<int>();
    test_underflow<long>();
    test_underflow<long long>();

    // unsigned integers
    test_underflow<unsigned char>();
    test_underflow<unsigned short int>();
    test_underflow<unsigned int>();
    test_underflow<unsigned long>();
    test_underflow<unsigned long long>();

    // real numbers
    test_underflow<float>();
    test_underflow<double>();
    test_underflow<long double>();
}

/// <summary>
/// Entry point into the application
/// </summary>
/// <returns>0 when complete</returns>
int main()
{
    //  create a string of "*" to use in the console
    const std::string star_line = std::string(50, '*');

    std::cout << "Starting Numeric Underflow / Overflow Tests!" << std::endl;

    // run the overflow tests
    do_overflow_tests(star_line);

    // run the underflow tests
    do_underflow_tests(star_line);

    std::cout << std::endl << "All Numeric Underflow / Overflow Tests Complete!" << std::endl;

    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
