// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <stdexcept>

// I added this include because I needed std::runtime_error and std::overflow_error
// for a couple of the TODOs below.. and those standard exception types live in stdexcept

// This is the custom exception class I made for the todo that just asks for a custom
// exception derived from std::exception. I inherit from std::exception and override
// the what() method since that is the one virtual function std::exception actually needs overridden and it just has to return a const char* describing what went wrong
class custom_exception : public std::exception
{
public:
  const char* what() const noexcept override
  {
    return "Custom Application Exception occurred";
  }
};

bool do_even_more_custom_application_logic()
{
  // TODO: Throw any standard exception

  // I throw a std::runtime_error here since that counts as a standard exception
  // and it makes sense in this spot.... something went wrong further down in the custom application logic so I treat this like a runtime problem
  std::cout << "Running Even More Custom Application Logic." << std::endl;

  throw std::runtime_error("Exception thrown from do_even_more_custom_application_logic");

  return true;
}
void do_custom_application_logic()
{
  // TODO: Wrap the call to do_even_more_custom_application_logic()
  //  with an exception handler that catches std::exception, displays
  //  a message and the exception.what(), then continues processing

  // I wrapped the call in a try block and catch std::exception by const reference then from there print out a message along with
  // e.what() so I can see exactly what exception got thrown. After the catch
  // block finishes the function just keeps going like the todo asked here
  std::cout << "Running Custom Application Logic." << std::endl;

  try
  {
    if(do_even_more_custom_application_logic())
    {
      std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
    }
  }
  catch (const std::exception& e)
  {
    std::cout << "Exception Caught in do_custom_application_logic: " << e.what() << std::endl;
  }

  // TODO: Throw a custom exception derived from std::exception
  //  and catch it explictly in main

  // This is where I throw the custom_exception class I defined up above. The todo listed
  // says to catch it in main so I do not put a try/catch around this
  // one here I just let it leave this function and travel up to main
  throw custom_exception();

  std::cout << "Leaving Custom Application Logic." << std::endl;

}

float divide(float num, float den)
{
  // TODO: Throw an exception to deal with divide by zero errors using
  //  a standard C++ defined exception

  // I ended up using std::overflow_error here since dividing by zero is the kind of math
  // error that fits under overflow_error and it is a standard c++ exception type that already exists in stdexcept so I do not need to build my own for this
  if (den == 0)
  {
    throw std::overflow_error("Divide by zero exception");
  }

  return (num / den);
}

void do_division() noexcept
{
  //  TODO: create an exception handler to capture ONLY the exception thrown
  //  by divide.

  // since divide throws a std::overflow_error I only catch that exact type here
  // not std::exception in general because the todo specifically says only the
  // exception thrown by divide. This function is also marked noexcept so it is not allowed to let any exception escape it catching the overflow_error here keeps that noexcept promise
  try
  {
    float numerator = 10.0f;
    float denominator = 0;

    auto result = divide(numerator, denominator);
    std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
  }
  catch (const std::overflow_error& e)
  {
    std::cout << "Exception Caught in do_division: " << e.what() << std::endl;
  }
}

int main()
{
  std::cout << "Exceptions Tests!" << std::endl;

  // TODO: Create exception handlers that catch (in this order):
  //  your custom exception
  //  std::exception
  //  uncaught exception
  //  that wraps the whole main function, and displays a message to the console.

  // I wrapped both function calls in one try block and added three catch blocks
  // underneath in the exact order the todo asks for... custom_exception has to go
  // first since it is the most specific type and if I put catch(const std::exception&)
  // first it would grab the custom_exception too since custom_exception is a kind
  // of std::exception and the catch(...) at the very end is my catch all that ends up
  // scooping up literally anything else that was not already caught above it
  try
  {
    do_division();
    do_custom_application_logic();
  }
  catch (const custom_exception& e)
  {
    std::cout << "Custom Exception Caught in main: " << e.what() << std::endl;
  }
  catch (const std::exception& e)
  {
    std::cout << "Standard Exception Caught in main: " << e.what() << std::endl;
  }
  catch (...)
  {
    std::cout << "Unknown Exception Caught in main." << std::endl;
  }
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
